﻿# DSH 本地增强插件（B 组）安装说明

这 9 个插件是命令级辅助功能，通过 Cordis 插件框架挂在 DSH profile 上。
目录是指向 workspace 的 junction，所以安装时要保证每个插件目录都可被 DSH 访问。

## 安装步骤

1. 解压本 zip，得到 9 个目录（dsh-*-plugin）
2. 把它们放进你的 workspace（比如 C:\Users\you\Documents\deepseek-harness\default-workspace\）
3. 每个目录已自带 package.json（含 name / main: index.js / dsh.bundle.patch）与 cordis.patch.yml
4. 在 profile 的 package.json 的 dsh.profile.bundles 和 dependencies 里登记这些包名（见下）
5. 重启 DSH 后，对应斜杠命令即可用

## 各插件包名 / 命令

| /./cordis.patch.yml |
| /./cordis.patch.yml |
| /./cordis.patch.yml |
| /./cordis.patch.yml |
| /./cordis.patch.yml |
| /./cordis.patch.yml |
| /./cordis.patch.yml |
| /./cordis.patch.yml |
| /./cordis.patch.yml |

## 运维提示

- 若 profile 被 DSH 重置，用 dsh-upgrades\restore-profile.ps1 还原
- 校验用 dsh-upgrades\verify-plugins.mjs 和 smoke-plugins.mjs
- 详见 dsh-upgrades\PLUGIN-MANIFEST.md 与 REPORT.md

## 两条硬规则

1. Cordis 任何 service 都要 inject 声明，否则 ctx.xxx 抛 "cannot get property X without inject"
2. 插件只用 node: 内建模块，不要 import 任何 @deepseek-ai/* 或第三方包
